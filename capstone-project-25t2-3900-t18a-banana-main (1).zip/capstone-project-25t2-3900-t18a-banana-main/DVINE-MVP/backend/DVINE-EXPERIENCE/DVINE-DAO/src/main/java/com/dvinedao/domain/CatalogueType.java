package com.dvinedao.domain;

public class CatalogueType {
    public static final Integer OFFICIAL_CATALOGUE = 0;
    public static final Integer PARTNER_CATALOGUE = 1;
}
