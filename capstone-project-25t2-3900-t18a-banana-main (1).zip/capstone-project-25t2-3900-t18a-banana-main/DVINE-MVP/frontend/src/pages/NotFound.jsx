export function NotFound() {
    return <h2>404 page not found</h2>
}